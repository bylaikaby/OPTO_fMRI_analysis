/*
 * netstreamer.cpp
 * 
 * NOTES : This mex uses threads to perform continuous streaming of
 *         incoming data. BUT current Matlab (R12) is a single-thread
 *         application, meaning not thread-safe. As far as i tested,
 *         mexEvalString(), mexCallMATLAB() crash the Matlab.
 *
 * To compile this mex link thread-safe library,
 *   >>mex netstreamer.cpp essnetapi.c libcmt.lib -D_MT
 *
 * ver. 1.00  07-Aug-2002  Yusuke MURAYAMA, MPI
 *      1.01  08-Aug-2002  YM
 *      1.02  12-Aug-2002  YM, bug fix of logout
 *      1.03  15-Oct-2002  YM, disable pragma comment(lib,"libcmt.lib") for complation in Matlab R13
 */

#include <stdio.h>
#include <stdlib.h>
#include <malloc.h>
#include <memory.h>
#include <string.h>

#if defined (_WIN32) || defined (_WIN64)
#  define  WIN32_LEAN_AND_MEAN
#  define  WIN64_LEAN_AND_MEAN
#  include <windows.h>
#  include <process.h>
//#  pragma comment(lib, "libcmt.lib")  // multithread static library
#  define EXCLUSION_INIT(a)    InitializeCriticalSection(a)
#  define EXCLUSION_DESTROY(a) DeleteCriticalSection(a)
#  define EXCLUSION_ENTER(a)   EnterCriticalSection(a)
#  define EXCLUSION_LEAVE(a)   LeaveCriticalSection(a)
//#  define WAIT_THREAD_END(a)   WaitForSingleObject(a,INFINITE)
#  define WAIT_THREAD_END(a)   Sleep(50)
typedef CRITICAL_SECTION  THREADLOCK;
typedef unsigned long THANDLE;
#else
#  include <stdio.h>
#  include <pthread.h>
#  define EXCLUSION_INIT(a)    pthread_mutex_init(a,NULL)
#  define EXCLUSION_DESTROY(a) pthread_mutex_destroy(a)
#  define EXCLUSION_ENTER(a)   pthread_mutex_lock(a)
#  define EXCLUSION_LEAVE(a)   pthread_mutex_unlock(a)
#  define WAIT_THREAD_END(a)   pthread_join(a,NULL)
typedef pthread_t THANDLE;
typedef pthread_mutex_t THREADLOCK;
#endif

#include "mex.h"
#include "matrix.h"

//#define NETAPI_IMPORT
#include "essnetapi.h"

// input/putput /////////////////////////////////////////
#define INP_COMMAND_STR  prhs[0]
#define INP_SERVER_NAME  prhs[1]
#define INP_SERVER_PORT  prhs[2]
#define INP_SOCKET       prhs[1]
#define INP_LOGIC_H      prhs[1]
#define INP_LOGIC_L      prhs[2]
#define OUT_SOCKET       plhs[0]
#define OUT_WAVE         plhs[0]
#define OUT_ENDTIME      plhs[1]
#define OUT_SAMPT        plhs[2]

// some definitions /////////////////////////////////////
#define DAQ_LOGIC_HIGH	16000   // about 2.5V = 65536/10*2.5
#define DAQ_LOGIC_LOW		6500    // about 1.0V = 65536/10*1.0
#define MAX_SOCKETS     16
#define MAX_BUFFERSIZE  1024*1024*2 // 4Mbytes for short integer, 
// 4M/(21kHz(pts/sec)*16chans*2bytes) = ~5.9sec

typedef struct _wswork {
  SOCKET m_sock;       // socket handle
  short  *m_buff;      // data buffer
  int    m_size;       // available size in pts
  double m_endtime;    // timestamp since beginobs in msec
  double m_samptime;   // samptime in msec
  int    m_numchans;   // numchans of data
  THANDLE m_thread;    // thread handle
  int    m_active;     // thread is running
  THREADLOCK m_lock;   // CRITICAL_SECTION or mutex
  short  m_logicH;
  short  m_logicL;
} WSWORK;

// global variables /////////////////////////////////////
short  gLogicH = DAQ_LOGIC_HIGH;
short  gLogicL = DAQ_LOGIC_LOW;
int    gNumSockets = 0;
WSWORK gWsWork[MAX_SOCKETS];

// prototypes ///////////////////////////////////////////
void netOnExt(void);
int  add_socket(SOCKET sock);
void remove_socket(SOCKET sock);
WSWORK *find_socket(SOCKET sock);
void close_wswork(WSWORK *pwork);
void cmd_login(int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[]);
void cmd_logout(int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[]);
void cmd_read(int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[]);
void cmd_llevel(int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[]);
#if defined (_WIN32)
void recv_thread(void *pdata);
void recv_threadThreshold(void *pdata);
#else
void *recv_thread(void *pdata);
void *recv_threadThreshold(void *pdata);
#endif
void sleep_thread(int msec);


// functions ////////////////////////////////////////////
void netOnExit(void)
{
  int i;

  enet_startup();
  for (i = 0; i < MAX_SOCKETS; i++) {
    if (gWsWork[i].m_sock != INVALID_SOCKET) {
      //enet_ws_logout(gWsWork[i].m_sock);
      enet_close(gWsWork[i].m_sock);
      gWsWork[i].m_sock = INVALID_SOCKET;
    }
    if (gWsWork[i].m_active) WAIT_THREAD_END(gWsWork[i].m_thread);
    if (gWsWork[i].m_buff != NULL) {
      free(gWsWork[i].m_buff);  gWsWork[i].m_buff = NULL;
    }
    EXCLUSION_DESTROY(&gWsWork[i].m_lock);
  }
  enet_cleanup();
}

int add_socket(SOCKET sock)
{
  int i;
  WSWORK *pwork;

  if (gNumSockets == MAX_SOCKETS)  return -1;
  
  for (i = 0; i < MAX_SOCKETS; i++) {
    if (gWsWork[i].m_sock == INVALID_SOCKET) break;
  }

  if (i >= MAX_SOCKETS)  {
    mexPrintf("%s: too many sockets (n=%d)\n",mexFunctionName(),gNumSockets);
    return -1;
  }
  pwork = &gWsWork[i];

  pwork->m_sock = sock;
  pwork->m_size = 0;
  pwork->m_logicL = gLogicL;
  pwork->m_logicH = gLogicH;
  // prepare buffer
  if (pwork->m_buff != NULL) {
    free(pwork->m_buff);   pwork->m_buff = NULL;
  }
  pwork->m_buff = (short *)malloc(MAX_BUFFERSIZE*sizeof(short));
  if (pwork->m_buff == NULL) goto on_error;
  // begin thread
#if defined (_WIN32)
  pwork->m_thread = _beginthread(recv_thread,0,(void *)pwork);
  if (pwork->m_thread == -1)  goto on_error;
#else
  if (pthread_create(&pwork->m_thread,NULL,
                     recv_thread,(void *)pwork) != 0)
    goto on_error;
#endif
  
  gNumSockets++;

  return gNumSockets;

 on_error:
  pwork->m_sock = INVALID_SOCKET;
  pwork->m_active = 0;
  if (pwork->m_buff != NULL) {
    free(pwork->m_buff);   pwork->m_buff = NULL;
  }
  return -1;
}

void remove_socket(SOCKET sock)
{
  WSWORK *pwork;

  if ((pwork = find_socket(sock)) == NULL)  return;

  close_wswork(pwork);
  gNumSockets--;
  
  return;
}

WSWORK *find_socket(SOCKET sock)
{
  int i;

  for (i = 0; i < MAX_SOCKETS; i++) {
    if (gWsWork[i].m_sock == sock) break;
  }
  if (i >= MAX_SOCKETS)  return NULL;

  //mexPrintf(" find_socket = %d\n",i);

  return &gWsWork[i];
}

void close_wswork(WSWORK *pwork)
{
  SOCKET sock;
  
  if (pwork == NULL)  return;

  // close socket
  sock = pwork->m_sock;
  pwork->m_sock = INVALID_SOCKET;
  //if (sock != INVALID_SOCKET)  enet_ws_logout(sock);
  if (sock != INVALID_SOCKET)  enet_close(sock);
  // wait the thread and free buffer
  if (pwork->m_active)  WAIT_THREAD_END(pwork->m_thread);
  pwork->m_active = 0;
  if (pwork->m_buff != NULL) {
    free(pwork->m_buff);  pwork->m_buff = NULL;
  }
  // clear other vars
  pwork->m_size = 0;
  pwork->m_numchans = 0;
  pwork->m_endtime = 0;
  pwork->m_samptime = 0;

  return;
}


#if defined (_WIN32)
void recv_thread(void *pdata)
#else
void *recv_thread(void *pdata)
#endif
{
  int bready,brecv, npts;
  struct enet_msgheader msgh;
  short *buff, prevLevel;
  int nchans,i;
  WSWORK *pwork;

  pwork = (WSWORK *)pdata;
  prevLevel = pwork->m_logicL;  buff = NULL;
  pwork->m_active = 1;
  while (pwork->m_sock != INVALID_SOCKET) {
    // is data ready?
    bready = enet_readable(pwork->m_sock,0);
    if (bready < 0)  goto on_exit;
    if (bready == 0) {
      sleep_thread(20);  continue;
    }
    // yes, let's get message header
    memset(&msgh,0,sizeof(msgh));
    brecv = enet_recv(pwork->m_sock,(char *)&msgh,sizeof(msgh),0);
    if (brecv != sizeof(msgh) || msgh.nelements < 0)  goto on_exit;
    if (msgh.nelements == 0)  continue;
    // gets data
    buff = (short *)malloc(msgh.nelements*sizeof(short));
    brecv = enet_recv(pwork->m_sock,(char *)buff,msgh.nbytes,0);
    if (brecv != msgh.nbytes)  goto on_exit;
    if (msgh.type != (short)WSTYPE_WAVEDATA || msgh.subtype <= 0) {
      free(buff);  buff = NULL;  
      continue;
    }

    // seems winstreamer settings to be changed.
    //if ((int)msgh.timestamp != (int)pwork->m_samptime)        Beep(970,80);
    //if (msgh.subtype != (short)pwork->m_numchans)  Beep(1940,80);

    if ((int)msgh.timestamp != (int)pwork->m_samptime || 
        msgh.subtype != (short)pwork->m_numchans) {
      pwork->m_size = 0;  pwork->m_endtime = 0;  prevLevel = pwork->m_logicL;
      // NOTES : samptime is in msec, numchans includes a trigger channel
      pwork->m_samptime = msgh.timestamp;  pwork->m_numchans = (int)msgh.subtype;
    }

    
    // retreive data
    EXCLUSION_ENTER(&pwork->m_lock);
    {
      nchans = pwork->m_numchans;
      // any space?
      brecv = msgh.nelements;                          // in pts
      brecv = brecv + pwork->m_size - MAX_BUFFERSIZE;  // in pts
      brecv = (brecv/nchans + 1)*nchans;               // multiply of nchans
      if (brecv > 0) {
        pwork->m_size = pwork->m_size - brecv;
        memmove(&(pwork->m_buff[0]),&(pwork->m_buff[brecv]),
                pwork->m_size*sizeof(short));
      }
      // copy data
      memcpy(&(pwork->m_buff[pwork->m_size]),&buff[0],msgh.nbytes);
      pwork->m_size = pwork->m_size + msgh.nelements;

      // check trigger level, skip=2!!!
      npts = 0;
      for (i = nchans-1;  i < msgh.nelements; i+=2*nchans) {
        if (buff[i] >  pwork->m_logicH && prevLevel < pwork->m_logicL) {
          // new obs entered
          pwork->m_endtime = 0;  npts = 0;
        }
        npts+=2;
        prevLevel = buff[i];  // update trigger level to check new-obs enter
      }
      pwork->m_endtime = pwork->m_endtime + ((double)npts)*pwork->m_samptime;
    }
    EXCLUSION_LEAVE(&pwork->m_lock);
    free(buff);  buff = NULL;
  }

 on_exit:
  //Beep(1940,80);  Beep(970,80);
  if (buff != NULL)  free(buff);
  pwork->m_active = 0;
  remove_socket(pwork->m_sock);

#if defined (_WIN32)
  _endthread();
#else
  return NULL;
#endif
}

#if defined (_WIN32)
void recv_threadThreshold(void *pdata)
#else
void *recv_threadThreshold(void *pdata)
#endif
{
  int bready, brecv, npts;
  struct enet_msgheader msgh;
  short *buff, trigLevel, prevLevel;
  int nchans,i,j,k;
  WSWORK *pwork;

  pwork = (WSWORK *)pdata;
  prevLevel = pwork->m_logicL;  buff = NULL;
  pwork->m_active = 1;
  while (pwork->m_sock != INVALID_SOCKET) {
    // is data ready?
    bready = enet_ready(pwork->m_sock,0);
    if (bready < 0)  goto on_exit;
    if (bready == 0) {
      sleep_thread(20);  continue;
    }
    // yes, let's get message header
    memset(&msgh,0,sizeof(msgh));
    brecv = enet_recv(pwork->m_sock,(char *)&msgh,sizeof(msgh),0);
    if (brecv != sizeof(msgh) || msgh.nelements < 0)  goto on_exit;
    if (msgh.nelements == 0)  continue;
    // gets data
    buff = (short *)malloc(msgh.nelements*sizeof(short));
    brecv = enet_recv(pwork->m_sock,(char *)buff,msgh.nbytes,0);
    if (msgh.type != (short)WSTYPE_WAVEDATA || msgh.subtype <= 0) {
      free(buff);  buff = NULL;
      continue;
    }

    // seems winstreamer settings to be changed.
    if (msgh.timestamp != pwork->m_samptime || 
        msgh.subtype != pwork->m_numchans) {
      pwork->m_size = 0;  pwork->m_endtime = 0;  prevLevel = pwork->m_logicL;
      // NOTES : samptime is in msec, numchans includes a trigger channel
      pwork->m_samptime = msgh.timestamp;  pwork->m_numchans = msgh.subtype;
    }

    // retreive data
    EXCLUSION_ENTER(&pwork->m_lock);
    {
      nchans = pwork->m_numchans;
      // any space?
      brecv = msgh.nelements/nchans*(nchans-1);        // in pts
      brecv = brecv + pwork->m_size - MAX_BUFFERSIZE;  // in pts
      brecv = (brecv/(nchans-1) + 1)*(nchans-1);       // multiply of nchans-1
      if (brecv > 0) {
        pwork->m_size = pwork->m_size - brecv;
        memmove(&(pwork->m_buff[0]), &(pwork->m_buff[brecv]),
                pwork->m_size*sizeof(short));
      }
      // check trigger level and copy data
      npts = 0;
      for (i = 0, j = pwork->m_size;  i < msgh.nelements; i+=nchans, j+=(nchans-1)) {
        trigLevel = buff[i+nchans-1];
        if (trigLevel >  pwork->m_logicH) {
          if (prevLevel < pwork->m_logicL) { // new obs entered
            pwork->m_endtime = 0;
            pwork->m_size = 0;  j = 0;
          }
          for (k = 0; k < nchans-1; k++)  pwork->m_buff[j+k] = buff[i+k];
          npts++;
        }
        prevLevel = trigLevel;  // update trigger level to check new-obs enter
      }
      pwork->m_size = pwork->m_size + npts*(nchans-1);
      pwork->m_endtime = pwork->m_endtime + (double)npts*pwork->m_samptime;
    }
    EXCLUSION_LEAVE(&pwork->m_lock);
    free(buff);  buff = NULL;
  }

 on_exit:
  if (buff != NULL)  free(buff);
  pwork->m_active = 0;
  remove_socket(pwork->m_sock);

#if defined (_WIN32)
  _endthread();
#else
  return NULL;
#endif
}

void sleep_thread(int msec)
{
#if defined (_WIN32)
  Sleep(msec);
#else
  
#endif
}

void cmd_login(int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[])
{
  char *server = NULL;
  int buflen;
  SOCKET sock;

  if (nrhs < 2)  mexErrMsgTxt(" no winstreamer host specified.");
  // get server name
  if (!mxIsChar(INP_SERVER_NAME)) 	mexErrMsgTxt(" failed to get server name");
  buflen = mxGetM(INP_SERVER_NAME)*mxGetN(INP_SERVER_NAME) + 1;
  server = (char *)mxCalloc(buflen,sizeof(char));
  mxGetString(INP_SERVER_NAME,server,buflen);
  // get server port
  if (nrhs > 2) {
    if (!mxIsNumeric(INP_SERVER_PORT)) {
      mexErrMsgTxt(" failed to get server port");
    }
    enet_ws_port = (int)mxGetScalar(INP_SERVER_PORT);
  } else {
    enet_ws_port =  WINSTREAMER_PORT;
  }
  sock = enet_ws_login(server);   mxFree(server);

  if (sock != INVALID_SOCKET) {
    if (add_socket(sock) < 0) {
      enet_ws_logout(sock);
      mexPrintf("%s: failed to add socket.\n",mexFunctionName());
      sock = INVALID_SOCKET;
    }
  }

  OUT_SOCKET = mxCreateDoubleMatrix(1,1,mxREAL);
  if (sock != INVALID_SOCKET)   *mxGetPr(OUT_SOCKET) = (double)sock;
  else                          *mxGetPr(OUT_SOCKET) = -1.; 

  return;
}

void cmd_logout(int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[])
{
  SOCKET sock;
  char *sockstr = NULL;
  int buflen;

  if (nrhs < 2)  mexErrMsgTxt(" no sock id specified.");
  // get socket
  if (mxIsChar(INP_SOCKET)) {
    buflen = mxGetM(INP_SOCKET)*mxGetN(INP_SOCKET) + 1;
    sockstr = (char *)mxCalloc(buflen,sizeof(char));
    mxGetString(INP_SOCKET,sockstr,buflen);
    if (stricmp(sockstr,"all") == 0) {
      for (buflen = 0; buflen < MAX_SOCKETS; buflen++) {
        close_wswork(&gWsWork[buflen]);
      }
      gNumSockets = 0;
    }
    mxFree(sockstr);
  } else if (mxIsNumeric(INP_SOCKET)) {
    sock = (SOCKET)mxGetScalar(INP_SOCKET);
    close_wswork(find_socket(sock));
  } else {
    mexErrMsgTxt(" failed to get socket");
  }

  return;
}

void cmd_read(int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[])
{
  SOCKET sock;
  int cpsize,i,nchans;
  double *dp, *p, endtime, sampt;
  short *tmpbuff = NULL;
  WSWORK *pwork = NULL;

  if (nrhs < 2)  mexErrMsgTxt(" no sock id specified.");
  if (!mxIsNumeric(INP_SOCKET))   mexErrMsgTxt(" failed to get socket");

  sock = (SOCKET)mxGetScalar(INP_SOCKET);
  if ((pwork = find_socket(sock)) != NULL) {
    tmpbuff = NULL;  cpsize = 0;
    EXCLUSION_ENTER(&pwork->m_lock);
    {
      endtime = pwork->m_endtime;
      sampt   = pwork->m_samptime;
      nchans  = pwork->m_numchans;
      cpsize  = pwork->m_size;
      if (cpsize > 0) {
        tmpbuff = (short *)mxCalloc(cpsize,sizeof(short));
        memcpy(tmpbuff,pwork->m_buff,cpsize*sizeof(short));
        pwork->m_size = 0;
      }
    }
    EXCLUSION_LEAVE(&pwork->m_lock);
    //mexPrintf("\n here0.1 %.4f %.4f %d %d ",endtime,sampt,nchans,cpsize);
    // waveform
    if (cpsize > 0) {
      OUT_WAVE = mxCreateDoubleMatrix(nchans,cpsize/nchans,mxREAL);
      dp = mxGetPr(OUT_WAVE);
      for (p = dp, i = 0; i < cpsize; i++)  *p++ = (double)tmpbuff[i];
    } else {
      OUT_WAVE = mxCreateDoubleMatrix(0,0,mxREAL);
    }
    if (tmpbuff != NULL)  mxFree(tmpbuff);
  } else {
    endtime = 0;
    sampt   = 0;
    OUT_WAVE = mxCreateDoubleMatrix(1,1,mxREAL);
    *mxGetPr(OUT_WAVE) = -1;
  }

  // endtime
  if (nlhs > 1) {
    OUT_ENDTIME = mxCreateDoubleMatrix(1,1,mxREAL);
    *mxGetPr(OUT_ENDTIME) = endtime;  // in msec
  }
  // sampt
  if (nlhs > 2) {
    OUT_SAMPT = mxCreateDoubleMatrix(1,1,mxREAL);
    *mxGetPr(OUT_SAMPT) = sampt;  // in msec
  }

  return;
}

void cmd_llevel(int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[])
{
  short logicH, logicL;

  if (nrhs != 3)  mexErrMsgTxt(" no logigH, logicL");
  if (!mxIsNumeric(INP_LOGIC_H))   mexErrMsgTxt(" failed to get logicH");
  if (!mxIsNumeric(INP_LOGIC_L))   mexErrMsgTxt(" failed to get logicL");
  logicH = (short)mxGetScalar(INP_LOGIC_H);
  logicL = (short)mxGetScalar(INP_LOGIC_L);

  if (logicH < logicL) {
    gLogicH = logicL;  gLogicL = logicH;
  } else {
    gLogicH = logicH;  gLogicL = logicL;
  }

  return;
}


/* MEX function */
void mexFunction(int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[])
{
  static int initialized = 0;
  char *cmdstr = NULL;
  int buflen;

  /* initialization */
  if (initialized == 0) {
    enet_startup();
    for (buflen = 0; buflen < MAX_SOCKETS; buflen++) {
      gWsWork[buflen].m_sock = INVALID_SOCKET;
      gWsWork[buflen].m_active = 0;
      gWsWork[buflen].m_buff = NULL;
      gWsWork[buflen].m_size = 0;
      gWsWork[buflen].m_numchans = 0;
      EXCLUSION_INIT(&gWsWork[buflen].m_lock);
    }
    gNumSockets = 0;
    mexAtExit(netOnExit);
    initialized = 1;
  }

  /* Check for proper number of arguments. */
  if (nrhs < 1) {
		mexEvalString("help netstreamer;");  return;
  }

  // get a command string
  if (!mxIsChar(INP_COMMAND_STR)) 	mexErrMsgTxt(" failed to get command");
  buflen = mxGetM(INP_COMMAND_STR)*mxGetN(INP_COMMAND_STR) + 1;
  cmdstr = (char *)mxCalloc(buflen,sizeof(char));
  mxGetString(INP_COMMAND_STR,cmdstr,buflen);

  if (stricmp(cmdstr,"read") == 0) {
    cmd_read(nlhs, plhs, nrhs, prhs);
  } else if (stricmp(cmdstr,"logout") == 0 ||
             stricmp(cmdstr,"logoff") == 0 ||
             stricmp(cmdstr,"close") == 0) {
    cmd_logout(nlhs, plhs, nrhs, prhs);
  } else if (stricmp(cmdstr,"login") == 0 ||
      stricmp(cmdstr,"logon") == 0 ||
      stricmp(cmdstr,"open") == 0) {
    cmd_login(nlhs, plhs, nrhs, prhs);
  } else if (stricmp(cmdstr,"logiclevel") == 0) {
    cmd_llevel(nlhs, plhs, nrhs, prhs);
  } else {
    mexErrMsgTxt(" not supported command.");
    //mexPrintf("%s ERROR: not supported command '%s'.\n",
    //          mexFunctionName(),cmdstr);
  }

  mxFree(cmdstr);

  return;

}
