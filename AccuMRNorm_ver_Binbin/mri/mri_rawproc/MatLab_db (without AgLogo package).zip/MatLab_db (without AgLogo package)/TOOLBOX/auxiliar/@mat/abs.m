% base matrix: absolute value of full matrix
%
% (c) by Hannes Nickisch, MPI for Biological Cybernetics, 2010 October 12

function B = abs(A)

  B = abs(full(A));