%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% Copyright (c) 2012
% Bruker BioSpin MRI GmbH
% D-76275 Ettlingen, Germany
%
% All Rights Reserved
%
% $Id: BrukerExample.m,v 1.1 2012/09/11 14:23:39 pfre Exp $
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%







%% Don't execute this script complete !!
% A small script with 2 easy examples, without usage of special parameters
%% This Script is meant to get partially marked and executed with F9.
error('This script is not for execution !! Please open it')




%% Start:
% Add with this command, the directory and all subdirectories to the matlab path: 
addBrukerPaths;

% try the help for this package:
doc Contents

% show Version
bruker_version

% save the path to the testdata in a variable
% the testdata are 5 slices of a kiwi
dirpath='./TestData/2/pdata/1';

%% Create rawData, frameData and cartesian kSpace-Data with the import-mode
    
    % create a RawDataObject
    rawObj=RawDataObject(dirpath);
    
    % lets show the sizes of the data, stored in ACQ_size:
    rawObj.Acqp.ACQ_size
    
    % now have a small look at some values:
    rawObj.data{1}(1,1:5,1:5)
    
    % create a FrameDataObject with the import of a RawDataObject
    frameObj=FrameDataObject(rawObj);
    
    % now have a small look at some values:
    frameObj.data(1:10,1:10,1)
    
    % create a cartesian-kSpace-DataObject with the import of a FrameDataObject
    %   (Currently this works only with FLASH, MSME, RARE and FISP)
    kdataObj=CKDataObject(frameObj);
    
        % you can see the spectrum, if you call the
        % .viewer-function of the object:
        kdataObj.viewer;
    
    clear rawObj frameObj kdataObj;
    
    
    
%% Create Data with shortcuts

    % directly create a FrameDataObject with a dirpath
    direct_frameObj=FrameDataObject(dirpath);
    
    clear direct_frameObj;
    
    % directly create a cartesian-kSpace-DataObject with a dirpath
    %   (Currently this works only with FLASH, MSME, RARE and FISP)
    direct_kdataObj=CKDataObject(dirpath);
    
        % you can see the spectrum, if you call the
        % .viewer-function of the object:
        direct_kdataObj.viewer;
    
%% using the reco in Matlab

    % read Reco-parameterfile
    direct_kdataObj=direct_kdataObj.readReco;
    
    % start reconstruction with 'all' recosteps and generating an 'image'-DataObject:
    imageObj=direct_kdataObj.reco('all', 'image');
    % it's the same like: imageObj=direct_kdataObj.reco({'quadrature', 'phase_rotate', 'zero_filling', 'FT', 'sumOfSquares', 'transposition'}, 'image');
    % visit:    doc CKDataObject.reco
    
    % open viewer
    imageObj.viewer;

    clear imageObj;
    
%% Read an Image from a ParaVision Image-File (Reco already done)

    % create object:
    imageObj=ImageDataObject(dirpath);

    % open viewer:
    imageObj.viewer;
    
    % set Path
    imageObj=imageObj.setDataPath('imagewrite', './writeToPV/2/pdata/1');
    
    % generate visu-parameterset for writing, with all optional parameters:
    imageObj=imageObj.genExportVisu('importAll');
    
    % check if the parameters are set correctly:
    imageObj.exportVisu
      
    % write Data
    imageObj.writeImage;
    
    
    clear imageObj;




