function adf_write(adffile,HDR,WVDATA,varargin)
%ADF_WRITE - Write ADF/ADFW file.
%  ADF_WRITE(ADFFILE,HDR,WVDATA) write HDR/wave as ADF/ADFW file.  'WVDATA' must be
%  a matrix of (time,chan) or a cell array of (time,chan).
%
%  EXAMPLE :
%    adf_write('myadf.adfw',hdr,wvdata)
%
%  VERSION :
%    0.90 03.11.08 YM  pre-release
%
%  See also adf_readHeader adf_split

if nargin < 3,  help adf_write; return;  end

if ~iscell(WVDATA),  WVDATA = { WVDATA };  end

% OPTIONAL SETTINGS
VERBOSE = 1;

for N = 1:2:length(varargin),
  switch lower(varargin{N}),
   case {'verbose'}
    VERBOSE = varargin{N+1};
  end
end




%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% ADF definition
ADF_HEADER_SIZE = 256;             % ADF header size, must be 256


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% validate header
if all(HDR.magic(:)' == [7 8 19 67]),
  adfw = 0;
elseif all(HDR.magic(:)' == [8 9 20 68]),
  adfw = 1;
else
  error(' ERROR %s:  unknown magic numbers.\n',mfilename);
end

nchan = size(WVDATA{1},2);
nobs  = length(WVDATA);

HDR.nchannels   = nchan;
HDR.nobs        = nobs;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% create directory
HDR.channeloffs = zeros(1,nchan);    % offset for each cannel in bytes
HDR.obscounts   = zeros(1,nobs);     % number of points for each obs
HDR.offsets     = zeros(1,nobs);     % offset for each obs in bytes

tmpoffs = 0;
for iObs = 1:nobs,
  HDR.obscounts(iObs) = size(WVDATA{iObs},1);
  HDR.offsets(iObs) = tmpoffs;
  tmpoffs = tmpoffs + HDR.obscounts(iObs) * 2;  % 2 as int16
end

for iCh = 1:nchan,
  HDR.channeloffs(iCh) = tmpoffs*(iCh-1) + ADF_HEADER_SIZE + 4*nchan + 4*nobs + 4*nobs;
end

if VERBOSE
  fprintf(' %s: writing ''%s'' hdr...',mfilename,adffile);
end


% open the file
fid = fopen(adffile,'wb','ieee-le');

% write header
fwrite(fid, HDR.magic(1:4),       'int8');
fwrite(fid, HDR.version(1),       'float');
fwrite(fid, HDR.nchannels(1),     'int8');
fwrite(fid, HDR.channels(1:16),   'int8');
fwrite(fid, HDR.numconv(1),       'int32');
fwrite(fid, HDR.prescale(1),      'int32');
fwrite(fid, HDR.clock(1),         'int32');
fwrite(fid, HDR.us_per_sample(1), 'float');
fwrite(fid, HDR.nobs(1),          'int32');
if adfw > 0,
  fwrite(fid, HDR.resolution(1),      'int8');
  fwrite(fid, HDR.input_range(1),     'int8');
  fwrite(fid, HDR.chan_gains(1:16),   'int8');
  fwrite(fid, HDR.scan_rate(1),       'float');
  fwrite(fid, HDR.samp_timebase(1),   'int16');
  fwrite(fid, HDR.samp_interval(1),   'int16');
  fwrite(fid, HDR.scan_timebase(1),   'int16');
  fwrite(fid, HDR.scan_interval(1),   'int16');
  fwrite(fid, HDR.trig_logic_high(1), 'int16');
  fwrite(fid, HDR.trig_logic_low(1),  'int16');
end

tmpdummy = zeros(1,256-ftell(fid),'int8');
fwrite(fid, tmpdummy, 'int8');

% write data directory
fwrite(fid, HDR.channeloffs(1:nchan), 'int32');
fwrite(fid, HDR.obscounts(1:nobs),    'int32');
fwrite(fid, HDR.offsets(1:nobs),      'int32');

if VERBOSE,
  fprintf(' data...');
end
% write data
for iCh = 1:nchan,
  for iObs = 1:nobs,
    tmpdat = int16(WVDATA{iObs}(:,iCh));
    fwrite(fid, tmpdat, 'int16');
  end
end

% close the file
fclose(fid);

if VERBOSE,
  fprintf(' done.\n');
end
