% PURPOSE : To read adf/adfw data of all channels in the observation.
% USAGE :   [wv npts sampt] = adf_readobs(filename,obs,[start],[width])
% SEEALSO : adf_info, adf_read
