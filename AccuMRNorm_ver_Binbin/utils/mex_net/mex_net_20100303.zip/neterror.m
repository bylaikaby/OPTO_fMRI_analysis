% PURPOSE : To get error code of network/socket
% USAGE :   error = neterror;
% RETURN :  error code
% NOTES :   requires "essnetapi.c" and "essnetapi.h"
% VERSION : 1.00 05-Aug-02  Yusuke MURAYAMA, MPI
