% base matrix: angle of full matrix
%
% (c) by Hannes Nickisch, MPI for Biological Cybernetics, 2010 October 12

function B = angle(A)

  B = angle(full(A));