function HDR = adf_readHeader(adffile)
%ADF_READHEADER - To read header info. of a ADF file
% PURPOSE : To read header info. of a ADF file
% USAGE : h = adf_readHeader([adffile]);
% VERSION : 1.00 12-May-2000  Yusuke MURAYAMA, MPI
%           1.01 24-Oct-2002  YM/MPI, supports adfwinfo file
% See also ADF_INFO ADF_READ
  
if ~exist('adffile','var'),
  [adffile,adfdir] = uigetfile(...
      {'*.adf;*.adfw', 'ADF/ADFW Files (*.adf,*.adfw)'; ...
       '*.*',         'All Files (*.*)'}, ...
      'Pick an ADF/ADFW file');
  if isequal(adffile,0) || isequal(adfdir,0), return;  end
  adffile = fullfile(adfdir,adffile);
end

if isempty(adffile),  return;  end
[adfdir,fn,fe] = fileparts(adffile);
adffile = sprintf('%s%s',fn,fe);
if ~isempty(adfdir),  adfdir = pwd;  end
fullpath = fullfile(adfdir,adffile);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% initialze output
HDR = [];

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% open it
fid = fopen(fullpath,'rb');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% read header
HDR.magic         = fread(fid,4, 'char');  HDR.magic = HDR.magic(:)';
if all(HDR.magic == [10 16 19 93]),
  adfw = 0;  unconv = 1;
elseif all(HDR.magic == [7 8 19 67]),
  adfw = 0;  unconv = 0;
elseif all(HDR.magic == [11 17 20 94]),
  adfw = 1;  unconv = 1;
elseif all(HDR.magic == [8 9 20 68]),
  adfw = 1;  unconv = 0;
else
  fclose(fid);
  error('\n Not ADF/ADFW file: %s\n',fullpath);
  return;
end
HDR.version       = fread(fid,1, 'float');
HDR.nchannels     = fread(fid,1, 'int8');
HDR.channels      = fread(fid,16,'int8');  HDR.channels = HDR.channels(:)';
HDR.numconv       = fread(fid,1, 'int32');
HDR.prescale      = fread(fid,1, 'int32');
HDR.clock         = fread(fid,1, 'int32');
HDR.us_per_sample = fread(fid,1, 'float');
HDR.nobs          = fread(fid,1, 'int32');
if adfw == 1,
  HDR.resolution  = fread(fid,1, 'int8');
  HDR.input_range = fread(fid,1, 'int8');
  HDR.chan_gains  = fread(fid,16,'int8'); HDR.chan_gains = HDR.chan_gains(:)';
  HDR.scan_rate   = fread(fid,1, 'float');
  HDR.samp_timebase = fread(fid,1, 'int16');
  HDR.samp_interval = fread(fid,1, 'int16');
  HDR.scan_timebase = fread(fid,1, 'int16');
  HDR.scan_interval = fread(fid,1, 'int16');
  HDR.trig_logic_high = fread(fid,1, 'int16');
  HDR.trig_logic_low  = fread(fid,1, 'int16');
end

if unconv == 1,
  fclose(fid);
  fprintf('\n unconverted ADF/ADFW file: %s\n',fullpath);
  return;
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% read directory
fseek(fid,256,'bof');
HDR.channeloffs   = fread(fid,HDR.nchannels,'int32'); HDR.channeloffs = HDR.channeloffs(:)';
HDR.obscounts     = fread(fid,HDR.nobs,     'int32'); HDR.obscounts   = HDR.obscounts(:)';
HDR.offsets       = fread(fid,HDR.nobs,     'int32'); HDR.offsets     = HDR.offsets(:)';

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% read optional directory if info
if ~isempty(findstr(adffile,'adfinfo')) || ~isempty(findstr(adffile,'adfwinfo')),
  fseek(fid,128,'cof');
  HDR.startoffs     = fread(fid,HDR.nobs,     'int32'); HDR.startoffs = HDR.startoffs(:)';
  HDR.stopoffs      = fread(fid,HDR.nobs,     'int32'); HDR.stopoffs  = HDR.stopoffs(:)';
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% close it
fclose(fid);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% verify vars

