function adf_write(adffile,HDR,WVDATA,varargin)
%ADF_WRITE - Write ADF/ADFW file.
%  ADF_WRITE(ADFFILE,HDR,WVDATA) write HDR/wave as ADF/ADFW file.  'WVDATA' must be
%  a matrix of (time,chan) or a cell array of (time,chan).
%
%  EXAMPLE :
%    adf_write('myadf.adfw',hdr,wvdata)
%
%  VERSION :
%    0.90 03.11.08 YM  pre-release
%
%  See also adf_readHeader adf_split

if nargin < 3,  help adf_write; return;  end

if ~iscell(WVDATA),  WVDATA = { WVDATA };  end

% OPTIONAL SETTINGS
VERBOSE = 1;

for N = 1:2:length(varargin),
  switch lower(varargin{N}),
   case {'verbose'}
    VERBOSE = varargin{N+1};
  end
end

[fp fr] = fileparts(adffile);

if all(HDR.magic(:)' == [ 7  8 19 67]),
  % adf
  adffile = fullfile(fp,sprintf('%s.adf',fr));
  sub_write_adfw(adffile,HDR,WVDATA,0,VERBOSE);
elseif all(HDR.magic(:)' == [ 8  9 20 68]),
  % adfw
  adffile = fullfile(fp,sprintf('%s.adfw',fr));
  sub_write_adfw(adffile,HDR,WVDATA,1,VERBOSE);
elseif all(HDR.magic(:)' == [ 9 10 21 69])
  % adfx
  adffile = fullfile(fp,sprintf('%s.adfx',fr));
  sub_write_adfx(adffile,HDR,EVDATA);
else
  error(' ERROR %s:  unknown magic numbers.\n',mfilename);
end


return



% ============================================================
function sub_write_adfw(adffile,HDR,EVDATA,IsAdfw,VERBOSE)
% ============================================================

% ADF definition
ADF_HEADER_SIZE = 256;             % ADF header size, must be 256


% validate the header information
nchan = size(WVDATA{1},2);
nobs  = length(WVDATA);

HDR.nchannels   = nchan;
HDR.nobs        = nobs;

% create directory
HDR.channeloffs = zeros(1,nchan);    % offset for each cannel in bytes
HDR.obscounts   = zeros(1,nobs);     % number of points for each obs
HDR.offsets     = zeros(1,nobs);     % offset for each obs in bytes

tmpoffs = 0;
for iObs = 1:nobs,
  HDR.obscounts(iObs) = size(WVDATA{iObs},1);
  HDR.offsets(iObs) = tmpoffs;
  tmpoffs = tmpoffs + HDR.obscounts(iObs) * 2;  % 2 as int16
end

for iCh = 1:nchan,
  HDR.channeloffs(iCh) = tmpoffs*(iCh-1) + ADF_HEADER_SIZE + 4*nchan + 4*nobs + 4*nobs;
end

if VERBOSE
  fprintf(' %s: writing ''%s'' hdr...',mfilename,adffile);
end

% open the file
fid = fopen(adffile,'wb','ieee-le');

% write header
fwrite(fid, HDR.magic(1:4),       'int8');
fwrite(fid, HDR.version(1),       'float');
fwrite(fid, HDR.nchannels(1),     'int8');
fwrite(fid, HDR.channels(1:16),   'int8');
fwrite(fid, HDR.numconv(1),       'int32');
fwrite(fid, HDR.prescale(1),      'int32');
fwrite(fid, HDR.clock(1),         'int32');
fwrite(fid, HDR.us_per_sample(1), 'float');
fwrite(fid, HDR.nobs(1),          'int32');
if IsAdfw > 0,
  fwrite(fid, HDR.resolution(1),      'int8');
  fwrite(fid, HDR.input_range(1),     'int8');
  fwrite(fid, HDR.chan_gains(1:16),   'int8');
  fwrite(fid, HDR.scan_rate(1),       'float');
  fwrite(fid, HDR.samp_timebase(1),   'int16');
  fwrite(fid, HDR.samp_interval(1),   'int16');
  fwrite(fid, HDR.scan_timebase(1),   'int16');
  fwrite(fid, HDR.scan_interval(1),   'int16');
  fwrite(fid, HDR.trig_logic_high(1), 'int16');
  fwrite(fid, HDR.trig_logic_low(1),  'int16');
end

tmpdummy = zeros(1,ADF_HEADER_SIZE-ftell(fid),'int8');
fwrite(fid, tmpdummy, 'int8');

% write data directory
fwrite(fid, HDR.channeloffs(1:nchan), 'int32');
fwrite(fid, HDR.obscounts(1:nobs),    'int32');
fwrite(fid, HDR.offsets(1:nobs),      'int32');

if VERBOSE,
  fprintf(' data...');
end
% write data
for iCh = 1:nchan,
  for iObs = 1:nobs,
    tmpdat = int16(WVDATA{iObs}(:,iCh));
    fwrite(fid, tmpdat, 'int16');
  end
end

% close the file
fclose(fid);

if VERBOSE,
  fprintf(' done.\n');
end


return




% ============================================================
function sub_write_adfx(adffile, HDR, WVDATA, VERBOSE)
% ============================================================
HDR.version         = fread(fid,  1, 'float');
HDR.datestr         = fread(fid, 32, 'char')';   HDR.datestr(HDR.datestr == 254)   = [];  HDR.datestr  = deblank(char(HDR.datestr));
HDR.numdevices      = fread(fid,  1, 'int32');
HDR.dev_numbers     = fread(fid, 32, 'int8')';
HDR.adc_resolution  = fread(fid, 32, 'int8')';
HDR.us_per_sample   = fread(fid,  1, 'double');
HDR.scan_rate_hz    = fread(fid,  1, 'double');
HDR.samp_rate_hz    = fread(fid,  1, 'double');
HDR.nchannels_ai    = fread(fid,  1, 'int32');
HDR.nchannels_di    = fread(fid,  1, 'int32');
HDR.obsp_chan       = fread(fid,  1, 'int32');
HDR.numconv         = fread(fid,  1, 'int32');
HDR.nobs            = fread(fid,  1, 'int32');
HDR.offset2dir      = fread(fid,  1, 'int32');
HDR.offset2data     = fread(fid,  1, 'int32');
HDR.obsp_logic_high = fread(fid,  1, 'int16');
HDR.obsp_logic_low  = fread(fid,  1, 'int16');

fseek(fid,256,'bof');

nch = HDR.nchannels_ai + HDR.nchannels_di;
HDR.devices         = fread(fid, nch, 'int8')';
HDR.data_type       = char(fread(fid, nch, 'char')');
HDR.channels        = fread(fid, nch, 'int')';
HDR.adc2volts       = fread(fid, nch, 'single')';

if unconv == 1,  return;  end

HDR.obscounts       = fread(fid, HDR.nobs, 'int32')';
HDR.offsets         = fread(fid, HDR.nobs, 'int64')'; 





if VERBOSE
  fprintf(' %s: writing ''%s'' hdr...',mfilename,adffile);
end


% open the file
fid = fopen(adffile,'wb','ieee-le');





return;
