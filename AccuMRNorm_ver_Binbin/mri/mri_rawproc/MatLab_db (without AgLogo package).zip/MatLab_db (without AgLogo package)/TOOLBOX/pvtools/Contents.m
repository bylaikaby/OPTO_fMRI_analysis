% Usefull commands and the files
%
%
% Set paths:
%   To use this help easier, please execute first addBrukerPaths.m to add the
%   subfolders to your matlab-path. Therefore you can mark the following line
%   and press F9, then restart the help
%   addBrukerPaths
%
%
% Accessing help:
%   doc                     - opens the Matlab help-browser, 
%                             e.g. doc RawDataObject or doc convertFrameToCKData
%   help                    - M-file help, displayed at the command line, 
%                             e.g. help RawDataObject
%   lookfor                 - Search all M-files for keyword.
%   methods                 - shows methods of an object, 
%                             e.g. methods RawDataObject
%   methodsview             - shows methods and additional Inoframtions of an object in a seperate window, 
%                             e.g. methodsview RawDataObject
%   properties              - shows variables of an object,
%                             e.g. properties RawDataObject
%
% Objects / Classes:
%   RawDataObject           - reads and stores raw-MRI-Objects, you can read ACQP-files, method-files, fid-files and job-files
%   FrameDataObject         - creates and stores framedata and store paremeterstructs
%   CKDataObject            - creates and stores kSpace-data, stores paremeterstructs and adds the preview-function to view images
%   ImageDataObject         - reads, stores image-data, writes image-data to ParaVision, stores paremeterstructs, starts the viewer
%
%
% Examples:
%   BrukerExample           - small script some easy examples, without usage of special parameters
%
%
%
% Expert usage
%
% Base-functions:
%   readBrukerParamFile     - reads Bruker JCAMP parameter files
%   readBrukerRaw           - reads Bruker raw-data files, means fid-file and job-files
%   convertRawToFrame       - sorts the scans from readBrukerRaw to frames
%   convertFrameToCKData    - sorts the frames form convertFrameToCKData to a kSpace-matrix,
%                             supports only RARE, FLASH, MSME, FISP actually
%   readBruker2dseq         - reads the 2dseq-file (=image) from disk
%   brViewer                - starts a viewer-application that support k-space-data and images
%
% More useful files in this package
%   bruker_addParamValue    - a small function to parse optional input-arguments
%   bruker_combineStructs   - combines two structs to one
%   bruker_findDataname     - a small function to search for filenames in a directory and its subdirectories
%   bruker_freqimage        - converts ONE 4D k-space frame into an image (freq->image), uses only fft an fftshifts
%   bruker_imagefreq        - converts ONE 4D image-frame into k-space (image->freq), uses only ifft an fftshifts
%   bruker_reco             - Makes an image-reconstruction based on the most important ParaVision-Reco-steps
%   bruker_requires         - fast check if some structs contain some variables
%   bruker_genVisu          - generates an visu-parameterset to export your dataset to Paravision
%   bruker_write2dseq       - writes only the 2dseq (=image) file onto disk
%   bruker_writeVisu        - writes only the visu_pars file (=exportVisu) file onto disk
%   bruker_version          - shows some version-informations about this package
%   bruker_getSelectedReceivers  - gives the number of used receivers from an Acqp-struct
%   bruker_genSlopeOffsMinMax    -  calculates the offset, dataslope, mins and maxs for writing images to disk 
%   bruker_getFrameGroupParams   - converts dependant Frame-Group-Variables into a matrixstruct with the FrameGroupDimensions
%   bruker_getTranspositionFrame - generates one frame of the dataset with transposition 
%   bruker_setTranspositionFrame - adds one frame to a dataset, considering the transposition




%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% Copyright (c) 2012
% Bruker BioSpin MRI GmbH
% D-76275 Ettlingen, Germany
%
% All Rights Reserved
%
% $Id: Contents.m,v 1.1 2012/09/11 14:23:39 pfre Exp $
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


