function k = get_k(X)

  k = X.k;
