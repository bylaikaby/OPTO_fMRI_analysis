%ADF_READ - To read out adf/adfw file
% PURPOSE : To read out adf/adfw file
% USAGE :  [wv npts sampt] = adf_read(filename,obs,chan,[start],[width])
% NOTES :  obs,chan,start>=0, width>=1
%           'start','width' is optional index to get a part of the
%           observation.
% See also ADF_INFO
