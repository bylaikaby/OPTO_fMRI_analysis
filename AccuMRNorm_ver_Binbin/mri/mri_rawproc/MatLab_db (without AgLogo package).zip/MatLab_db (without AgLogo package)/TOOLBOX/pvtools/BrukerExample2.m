% testBruker.m
% Demo of the Bruker matlab package. 
% FHEN Bruker-BioSpin MRI 2013.01.08

% This scripot uses the CKDataObject class to read and sort Cartesian
% kspace data. 

clear 
close all

% path to the expno 
path = '/opt/PV5.1/data/fhen/nmr/matlab1ch.hP1/6';

% read raw data and parameters from this path:
kdataObj = CKDataObject(path, 'useMethod', true);

% Now, kdataObj (an object of the class CKDataObject)
% contains the sorted cartesian k-space data in the 
% complex matrix:
%    kdataObj.data 
% and the ACQP and PVM parameters in the structures
%    kdataObj.Acqp and
%    kdataObj.Method, 
% respectively.
% The dimensions (sizes) of .data, in the order of indexing, are
%   read,            (PVM_Matrix[0])
%   phase2d,         (PVM_Matrix[1] or 1)
%   phase3d,         (PVM_Matrix[2] or 1)  
%   spect,           (?)
%   channels,        (PVM_EncNReceivers)
%   objects          (NI),    
%   repetitions      (NR).
% The data is sorted according to phase encoding order (PVM_EncSteps1,2)
% and slice excitation order (ACQ_obj_order). In case of accelerated 
% acquisition, missing k-space lines are zero-filled.


% Access to paarameters.
% Example 1: PVM_EchoTime:
te = kdataObj.Method.PVM_EchoTime;
% Example 2: NR
nr = kdataObj.Acqp.NR;
% all remaining ACQP and PVM parameters can be read in thi way.

% Viewing the k-space data
kdataObj.viewer

% Simple 1-4D reconstruction of all channels, slices, repetitions

kdat = kdataObj.data;
siz = size(kdat);
dim = length(siz);
kdat = fftshift(fft(fftshift(kdat,1),[],1),1);
if (dim> 1) && siz(2)>1
    kdat = fftshift(fft(fftshift(kdat,2),[],2),2);
end
if (dim > 2) && siz(3)>1
    kdat = fftshift(fft(fftshift(kdat,3),[],3),3);
end
if (dim > 3) && siz(4)>1
    kdat = fftshift(fft(kdat,[],4),4);
end

% replacing object's data by reconstructed images and viewing:
kdataObj.data = kdat;
kdataObj.viewer




