%ADF_INFO - To get info of ADF/ADFW file.
% PURPOSE : To get info of ADF/ADFW file
% USAGE :  [nchan nobs sampt obslens] = adf_info(filename)
% NOTES :  sampt in msec, obslens in pts
%          'obslens' is an array of all obs lengths.
% See also ADF_READ 
