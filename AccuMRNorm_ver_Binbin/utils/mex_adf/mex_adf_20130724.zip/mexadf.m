%
% mexadf.m : batch file to make all mex DLLs.
%
% VERSION : 1.00  02-Sep-2000  YM
%           1.01  29-Mar-2001  YM, adds cnvadfw
%           1.02  06-Dec-2012  YM, adds cnvadfx
%           1.03  01-Mar-2013  YM, adds adf_readdi

% adf_xxx
mex adf_info.c                   adfapi.c adfwapi.c adfxapi.c
mex adf_read.c                   adfapi.c adfwapi.c adfxapi.c
mex adf_readobs.c                adfapi.c adfwapi.c adfxapi.c
mex adf_readdi.c                 adfapi.c adfwapi.c adfxapi.c
mex adf_makeConvInfoFile.c       adfapi.c adfwapi.c adfxapi.c
mex adf_readFileAndInfo.c        adfapi.c adfwapi.c adfxapi.c
mex adf_readFileAndInfoByTime.c  adfapi.c adfwapi.c adfxapi.c

% cnvadfw/cnvadfx
mex cnvadfw.c                    adfapi.c adfwapi.c -D_USE_IN_MATLAB
mex cnvadfx.c                    adfapi.c adfwapi.c adfxapi.c -D_USE_IN_MATLAB
