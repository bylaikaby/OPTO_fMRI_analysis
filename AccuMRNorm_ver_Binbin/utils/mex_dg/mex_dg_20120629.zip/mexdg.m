%
% mexdg.m : batch file to make all mex DLLs
%
% VERSION :
%   1.00  24-Nov-2001  YM
%   1.01  02-Mar-2010  YM
%   1.02  29-Jun-2012  YM  use zlib-1.2.7
%

% c = input('Link with static zlib? Y/N[N]: ','s');
% if isempty(c), c = 'N';  end

% fprintf('making dg_read... ');
% switch lower(c)
%  case 'y'
%   % link with static zlib, no need of zlib.dll
%   mex -L. -I. dg_read.c dynio.c df.c dfutils.c flip.c zlibstatmt.lib
%   %mex dg_read.c zlibstat.lib
%   fprintf(' done.\n');
%  case 'n'
%   % link with zlibdll.lib, requires zlib.dll somwhere
%   mex -L. -I. dg_read.c dynio.c df.c dfutils.c flip.c zlib.lib
%   fprintf(' done.\n');
%   fprintf('Make sure you have zlib.dll somewhere in your PATH.\n');
%  otherwise
%   fprintf('not supported yet\n');
% end




switch lower(mexext)
 case {'mexw64'}
  mex -L. -I. dg_read.c dynio.c df.c dfutils.c flip.c zlibstat-1.2.7_win64.lib
 case {'mexw32','dll'}
  mex -L. -I. dg_read.c dynio.c df.c dfutils.c flip.c zlibstat-1.2.7.lib
 otherwise
  fprintf(' %s: mexext=''%s'' not supported yet.\n',mfilename,mexext);
end

