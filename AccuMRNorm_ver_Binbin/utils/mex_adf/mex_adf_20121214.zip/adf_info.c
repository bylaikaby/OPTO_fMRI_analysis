/*=================================================================
 *
 * READADF.C	.MEX file to read adf observation periods from ADF
 *              files
 *
 * The calling syntax is:
 *
 *		[nchan nobs sampt obslens] = adf_info(filename);
 *
 * To compile in Matlab:
 *  Make sure you have run "mex -setup"
 *  Then at the command prompt:
 *     >> mex adf_read.c adfapi.c adfwapi.c
 *
 *  You should then adf_read function available
 *
 *=================================================================*/
/* $Revision: 1.0  $ */
/* $Revision: 1.01 $ 02-Jun-2000 YM/MPI : supports also adfw format */
/* $Revision: 1.02 $ 04-Apr-2001 YM/MPI : add output of obslengths  */
/* $Revision: 1.03 $ 26-Oct-2001 YM/MPI : supports new adfw API     */
/* $Revision: 1.04 $ 07-Oct-2002 YM/MPI : bug fix                   */
/* $Revision: 1.05 $ 12-Oct-2002 YM/MPI : warns unconverted file    */

#include <math.h>
#include <stdio.h>
#include "matrix.h"
#include "mex.h"
#include "adfapi.h"    /* adf  file format */
#include "adfwapi.h"   /* adfw file format */

/* Input Arguments */
#define	FILE_IN	   prhs[0]

/* Output Arguments */
#define	ADF_NCHAN  plhs[0]
#define	ADF_NOBS	 plhs[1]
#define ADF_SAMPT  plhs[2]
#define	ADF_OBSLENGTHS plhs[3]


void mexFunction( int nlhs, mxArray *plhs[], 
		  int nrhs, const mxArray*prhs[] )
{ 
  FILE *fp;
  ADF_HEADER *h = NULL;
  ADFW_HEADER *hw = NULL;
  char *filename;
  int status, i, ftype;
  int nchan, nobs;
  double sampt, *obslensptr;

  /* Check for proper number of arguments */
  if (nrhs != 1) {
    mexPrintf("Usage: [nchan nobs sampt obslens] = adf_info(filename)\n");
    mexPrintf("Notes: sampt in msec, obslens in pts,  ver.1.05 Oct-2002\n");
    return;
  }

  /* Get the filename */
  if (mxIsChar(FILE_IN) != 1 || mxGetM(FILE_IN) != 1) {
    mexErrMsgTxt("adf_info: first arg must be filename string"); 
  }
  i = (mxGetM(FILE_IN) * mxGetN(FILE_IN)) + 1;
  filename = mxCalloc(i, sizeof(char));
  status = mxGetString(FILE_IN, filename, i);
  if (status != 0)
    mexWarnMsgTxt("adf_info: not enough space, filename string is truncated.");
  
  /* Open the file */
  fp = fopen(filename, "rb");
  if (!fp) {
    mexPrintf("adf_info: adffile='%s'\n",filename);
    mexErrMsgTxt("adf_info: file not found."); 
  }
  /* check file format */
  ftype = adfw_getFileFormat(fp);
  switch (ftype) {
  case ADF_WIN30_UNCONV :
    mexPrintf("adf_info: file (12bitsAD) not converted yet. '%s'\n",filename);
  case ADF_WIN30_CONV :
    h = adf_readHeader(fp);
    if (h == NULL) {
      fclose(fp);
      mexPrintf("adf_info: adffile='%s'\n",filename);
      mexErrMsgTxt("adf_info: faild to read header");
    }
    nchan = h->nchannels;
    nobs  = h->nobs;
    sampt = (double)h->us_per_sample/1000.;  /* in milliseconds */
    if (ftype == ADF_WIN30_UNCONV)  nobs = 0;
    break;
  case ADF_PCI6052E_UNCONV :
    mexPrintf("adf_info: file (16bitsAD) not converted yet. '%s'\n",filename);
  case ADF_PCI6052E_CONV :
    hw = adfw_readHeader(fp);
    if (hw == NULL) {
      fclose(fp);
      mexPrintf("adf_info: adffile='%s'\n",filename);
      mexErrMsgTxt("adf_info: faild to read header");
    }
    nchan = hw->nchannels;
    nobs  = hw->nobs;
    sampt = (double)hw->us_per_sample/1000.;  /* in milliseconds */
    if (ftype == ADF_PCI6052E_UNCONV)  nobs = 0;
    break;
  default:
    fclose(fp);
    mexPrintf("adf_info: adffile='%s'\n",filename);
    mexErrMsgTxt("adf_info: not adf/adfw file"); break;
  }
  fclose(fp);

  ADF_NCHAN = mxCreateDoubleMatrix(1, 1, mxREAL);
  ADF_NOBS  = mxCreateDoubleMatrix(1, 1, mxREAL);
  ADF_SAMPT = mxCreateDoubleMatrix(1, 1, mxREAL);
  *mxGetPr(ADF_NCHAN) = (double)nchan;
  *mxGetPr(ADF_NOBS)  = (double)nobs;
  *mxGetPr(ADF_SAMPT) = sampt;

  // observation lengths
  if (nlhs > 3) {
    ADF_OBSLENGTHS = mxCreateDoubleMatrix(nobs, 1, mxREAL);
    obslensptr = mxGetPr(ADF_OBSLENGTHS);
    if (ftype == ADF_WIN30_CONV) {
      for (i = 0; i < nobs; i++)  *obslensptr++ = (double)h->obscounts[i];
    } else if (ftype == ADF_PCI6052E_CONV) {
      for (i = 0; i < nobs; i++)  *obslensptr++ = (double)hw->obscounts[i];
    }
  }
  
  if (h != NULL)   adf_freeHeader(h);
  if (hw != NULL)  adfw_freeHeader(hw);
  
  return;
}
