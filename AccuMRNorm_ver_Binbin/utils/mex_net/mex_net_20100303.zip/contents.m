% MEX utilities for online control/monitoring via TCP/IP.
% =============================
%	getHostName - Get host name
%	neterror - Shows error of network.
%	neteventlog - Recieve ess-events from 'essmailer'.
%	netstimctrl - low level communication with stim/stimcon.
%	rmt_send - Send a command string to stim/stimcon.
%	netstreamer - Recieve analog data from WinStreamer.
%	removeTriggerData - Remove trigger signal from recieved analog data.
%	mexnet - Compile network utilities.
%
