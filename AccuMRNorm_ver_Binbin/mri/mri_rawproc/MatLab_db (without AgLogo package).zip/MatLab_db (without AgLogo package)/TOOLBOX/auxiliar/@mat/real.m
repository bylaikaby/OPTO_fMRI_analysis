% base matrix: real part of full matrix
%
% (c) by Hannes Nickisch, MPI for Biological Cybernetics, 2010 October 12

function B = real(A)

  B = real(full(A));