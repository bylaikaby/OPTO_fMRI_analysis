% MEX utilities for DGZ event file.
% =============================
%	dg_read - Read event data from a dgzfile.
%	mexdg - Compile DG utilities.
