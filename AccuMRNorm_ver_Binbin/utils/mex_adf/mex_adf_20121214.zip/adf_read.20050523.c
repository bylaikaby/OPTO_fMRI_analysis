/*=================================================================
 *
 * READADF.C	.MEX file to read adf observation periods from ADF
 *              files
 *
 * The calling syntax is:
 *
 *		[wv npts sampt] = adf_read(filename, obs, chan, [start],[width])
 *
 * To compile in Matlab:
 *  Make sure you have run "mex -setup"
 *  Then at the command prompt:
 *     >> mex adf_read.c adfapi.c adfwapi.c
 *
 *  You should then adf_read function available
 *
 *=================================================================*/
/* $Revision: 1.0  $ */
/* $Revision: 1.01 $ 02-Jun-2000 YM/MPI : supporting adfw format */
/* $Revision: 1.02 $ 29-Mar-2001 YM/MPI : message for unconverted file */
/* $Revision: 1.03 $ 26-Oct-2001 YM/MPI : supports new adfw API  */
/* $Revision: 1.04 $ 05-Oct-2002 YM/MPI : supports partial reading  */
/* $Revision: 1.05 $ 24-May-2005 YM/MPI : supports "int" data type  */

#include <math.h>
#include <stdio.h>
#include "matrix.h"
#include "mex.h"
#include "adfapi.h"    /* adf  file format */
#include "adfwapi.h"   /* adfw file format */

/* Input Arguments */
#define	FILE_IN	     prhs[0]
#define	INDEX_IN	   prhs[1]
#define	CHAN_IN	     prhs[2]
#define STARTINDX_IN prhs[3]
#define TOTWIDTH_IN  prhs[4]
#define DATATYPE_IN  prhs[5]

/* Output Arguments */
#define	ADF_OUT	     plhs[0]
#define	ADF_LENGTH	 plhs[1]
#define ADF_RATE     plhs[2]

static int resolution = 12;


void mexFunction( int nlhs, mxArray *plhs[], 
		  int nrhs, const mxArray*prhs[] )
{
  FILE *fp = NULL;
  ADF_HEADER *h = NULL;
  ADFW_HEADER *hw = NULL;
  char *filename;
  int obsindex, channel, startidx, totwidth;
  int status, i, npts, ftype, datatype;
  short *vals;
  double offset = (double) (1<<(resolution-1));
  void *dp;
  int dims[2];

  /* Check for proper number of arguments */
  if (nrhs == 0) {
    mexPrintf("Usage: [wv npts sampt] = adf_read(filename,obs,chan,[start],[width],[datatype])\n");
    mexPrintf("Notes: obs,chan,start>=0, width>=1,  start,width in pts, datatype as [double|single|int]\n");
    mexPrintf("                                       ver.1.05 May-2005\n");
    return;
  }
  if (nrhs < 3) { 
    mexErrMsgTxt("adf_read: Three input arguments required."); 
  } else if (nrhs == 4) {
    mexErrMsgTxt("adf_read: Width in pts required for partial reading.");
  } else if (nlhs > 6) {
    mexErrMsgTxt("adf_read: Too many output arguments."); 
  } 

  /* Get the filename */
  if (mxIsChar(FILE_IN) != 1 || mxGetM(FILE_IN) != 1) {
    mexErrMsgTxt("adf_read: first arg must be filename string"); 
  }
  i = (mxGetM(FILE_IN) * mxGetN(FILE_IN)) + 1;
  filename = mxCalloc(i, sizeof(char));
  status = mxGetString(FILE_IN, filename, i);
  if (status != 0)
    mexWarnMsgTxt("adf_read: not enough space, filename string is truncated.");
  
  /* Get the obs/channel index */
  obsindex = (int) mxGetScalar(INDEX_IN);
  channel = (int) mxGetScalar(CHAN_IN);
  /* Get start index/total width */
  startidx = 0;
  totwidth = -1;
  if (nrhs > 3) {
    if (mxGetNumberOfElements(STARTINDX_IN) > 0) {
      startidx = (int) mxGetScalar(STARTINDX_IN);
      if (startidx < 0)   mexErrMsgTxt("adf_read: start index must be >= 0.");
    }
    if (mxGetNumberOfElements(TOTWIDTH_IN) > 0) {
      totwidth = (int) mxGetScalar(TOTWIDTH_IN);
      if (totwidth <= 0)  mexErrMsgTxt("adf_read: read width must be >= 1.");
    }
  }
  /* Get data type */
  datatype = mxDOUBLE_CLASS;
  if (nrhs > 5) {
    if (mxIsChar(DATATYPE_IN) != 1) {
      mexErrMsgTxt("adf_read: 6th arg must be datatype string [double|single(float)|int]"); 
    }
    if (mxGetNumberOfElements(DATATYPE_IN) > 1) {
      char datastr[16];
      status = mxGetString(DATATYPE_IN,datastr,12);
      //printf("%s", datastr);
      if (strnicmp(datastr,"int",3) == 0) {
        datatype = mxINT16_CLASS;
      } else if (strnicmp(datastr,"double",6) == 0) {
        datatype = mxDOUBLE_CLASS;
      } else if (strnicmp(datastr,"float",5) == 0) {
        datatype = mxSINGLE_CLASS;
      } else if (strnicmp(datastr,"single",6) == 0) {
        datatype = mxSINGLE_CLASS;
      } else {
        mexErrMsgTxt("adf_read: 6th arg must be datatype string [double|single(float)|int]"); 
      }
    }
  }

  /* open the file */
  fp = fopen(filename, "rb");
  if (!fp) {
    mexPrintf("adf_read: adffile='%s'\n",filename);
    mexErrMsgTxt("adf_read: file not found.");
  }

  /* check file format */
  ftype = adfw_getFileFormat(fp);
  switch (ftype) {
  case ADF_WIN30_UNCONV :
  case ADF_PCI6052E_UNCONV :
    fclose(fp);
    mexPrintf("adf_read: adffile='%s'\n",filename);
    mexErrMsgTxt("adf_read: unconverted file");
    break;
  case ADF_WIN30_CONV :
    h = adf_readHeader(fp);
    break;
  case ADF_PCI6052E_CONV :
    hw = adfw_readHeader(fp);
    break;
  default:
    fclose(fp);
    mexPrintf("adf_read: adffile='%s'\n",filename);
    mexErrMsgTxt("adf_read: not adf/adfw file");
  }

  if (h == NULL && hw == NULL) {
    fclose(fp);
    mexPrintf("adf_read: adffile='%s'\n",filename);
    mexErrMsgTxt("adf_read: invalid header info for adf/adfw");
  }

  /* read data */
  if (ftype == ADF_WIN30_CONV) {
    if (totwidth < 0) {
      status = adf_getObsPeriod(h, fp, channel, obsindex, &npts, &vals);
    } else {
      status = adf_getObsPeriodPartial(h, fp, channel, obsindex, startidx, totwidth, &npts, &vals);
    }
  } else {
    if (totwidth < 0) {
      status = adfw_getObsPeriod(hw, fp, channel, obsindex, &npts, &vals);
    } else {
      status = adfw_getObsPeriodPartial(hw, fp, channel, obsindex, startidx, totwidth, &npts, &vals);
    }
    //printf("channeloffs=%d\n", hw->channeloffs[0]);
    //printf("obscounts=%d\n", hw->obscounts[0]);
    //printf("offsets=%d\n", hw->offsets[0]);
  }
  fclose(fp);  fp = NULL;

  if (status < 0) {
    if (status == -1)  mexErrMsgTxt("adf_read: channel out of range.");
    if (status == -2)  mexErrMsgTxt("adf_read: obs period out of range.");
    if (status == -3)  mexErrMsgTxt("adf_read: start/width out of range.");
    return;
  }

  /* Create a matrix for the return argument */
  dims[0] = 1;  dims[1] = npts;
  if (datatype == mxDOUBLE_CLASS) {
    double *p;
    ADF_OUT = mxCreateDoubleMatrix(1, npts, mxREAL);
    dp = mxGetData(ADF_OUT);
    if (ftype == ADF_WIN30_CONV) {
      for (p = (double *)dp, i = 0; i < npts; i++) *p++ = vals[i]-offset;
    } else {
      for (p = (double *)dp, i = 0; i < npts; i++) *p++ = vals[i];
    }
  } else if (datatype == mxINT16_CLASS) {
    int *p;
    ADF_OUT = mxCreateNumericArray(2, dims, mxINT16_CLASS, mxREAL);
    dp = mxGetData(ADF_OUT);
    if (ftype == ADF_WIN30_CONV) {
      for (p = (int *)dp, i = 0; i < npts; i++) *p++ = vals[i]-(int)offset;
    } else {
      memcpy(dp, vals, npts*sizeof(short));
    }
  } else if (datatype == mxSINGLE_CLASS) {
    float *p;
    ADF_OUT = mxCreateNumericArray(2, dims, mxSINGLE_CLASS, mxREAL);
    dp = mxGetData(ADF_OUT);
    if (ftype == ADF_WIN30_CONV) {
      for (p = (float *)dp, i = 0; i < npts; i++) *p++ = vals[i]-(float)offset;
    } else {
      for (p = (float *)dp, i = 0; i < npts; i++) *p++ = vals[i];
    }
  }
  free(vals);

  if (nlhs > 1) {
    // read length
    ADF_LENGTH = mxCreateDoubleMatrix(1, 1, mxREAL);
    *mxGetPr(ADF_LENGTH) = (double) npts;
    // sampling time in msec
    if (nlhs > 2) {
      ADF_RATE = mxCreateDoubleMatrix(1, 1, mxREAL);
      if (ftype == ADF_WIN30_CONV) {
        *mxGetPr(ADF_RATE) = (double) h->us_per_sample /1000.;
      } else {
        *mxGetPr(ADF_RATE) = (double) hw->us_per_sample / 1000.;
      }
    }
  }

  if (h != NULL)   adf_freeHeader(h);
  if (hw != NULL)  adfw_freeHeader(hw);

  return;

}
