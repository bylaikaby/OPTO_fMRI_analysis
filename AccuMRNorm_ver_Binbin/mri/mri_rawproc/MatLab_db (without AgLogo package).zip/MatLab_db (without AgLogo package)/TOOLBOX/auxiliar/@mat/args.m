% base matrix: argument list for composed matrices
%
% (c) by Hannes Nickisch, MPI for Biological Cybernetics, 2010 October 12

function arg = args(A)

  arg = A.args;