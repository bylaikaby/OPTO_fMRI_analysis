%
% mexadf.m : batch file to make all mex DLLs.
%
% VERSION : 1.00  02-Sep-2000  YM
%           1.01  29-Mar-2001  YM, adds cnvadfw

% adf_xxx
mex adf_info.c                   adfapi.c adfwapi.c
mex adf_read.c                   adfapi.c adfwapi.c
mex adf_readobs.c                adfapi.c adfwapi.c
mex adf_makeConvInfoFile.c       adfapi.c adfwapi.c
mex adf_readFileAndInfo.c        adfapi.c adfwapi.c
mex adf_readFileAndInfoByTime.c  adfapi.c adfwapi.c

% cnvadfw
mex cnvadfw.c                    adfapi.c adfwapi.c -D_USE_IN_MATLAB
